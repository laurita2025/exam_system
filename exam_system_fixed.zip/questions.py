questions = [
    {
        "question": "Pregunta 1 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 2 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 3 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 4 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 5 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 6 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 7 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 8 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 9 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 10 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 11 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 12 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 13 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 14 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 15 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 16 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 17 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 18 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 19 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 20 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 21 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 22 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 23 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 24 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 25 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 26 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 27 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 28 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 29 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 30 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 31 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 32 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 33 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 34 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 35 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 36 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 37 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 38 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 39 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 40 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 41 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 42 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 43 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 44 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 45 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 46 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 47 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 48 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 49 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
    {
        "question": "Pregunta 50 de Python",
        "options": ["Opción A", "Opción B", "Opción C", "Opción D"],
        "answer": "Opción A"
    },
]